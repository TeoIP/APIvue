// store.js
import { reactive } from 'vue';

export const store = reactive({
    cart: [],
    cartCount: {},

    addCart(product) {
        if (!this.cartCount[product.id]) {
            this.cart.push(product);
            this.cartCount[product.id] = 1;
        } else {
            this.cartCount[product.id]++;
        }
    },

    minusCart(product) {
        if (this.cartCount[product.id] > 1) {
            this.cartCount[product.id]--;
        } else {
            const index = this.cart.findIndex((item) => item.id === product.id);
            if (index !== -1) {
                this.cart.splice(index, 1);
                delete this.cartCount[product.id];
            }
        }
    },

    plusCart(product) {
        if (!this.cartCount[product.id]) {
            this.cartCount[product.id] = 1;
        }
        this.cartCount[product.id]++;
    },

    getCartTotalPrice() {
        return this.cart.reduce((total, item) => {
            const price = item.price || item.priceRegular;
            return total + price * this.cartCount[item.id];
        }, 0);
    },
});
