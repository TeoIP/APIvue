<template>
  <div id="app">
    <GroupSlider
        v-for="group in groups"
        :key="group.grouyId"
        :group="group"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
import GroupSlider from './components/GroupSlider.vue';

const groups = ref([]);

onMounted(() => {
  axios.get('http://localhost:10100/api/get-homepage-products')
      .then(response => {
        groups.value = response.data;
      });
});
</script>

<style>
#app{
  display: flex;
  flex-direction: column;
  gap: 50px;
}
</style>
