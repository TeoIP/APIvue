<template>
  <div class="slider">
    <button @click="prevSlide">Prev</button>
    <div class="slides">
      <div
          v-for="(slide, index) in slides"
          :key="index"
          :class="{ active: index === currentIndex }"
          class="slide"
      >
        <div v-for="product in slide" :key="product.id" class="product">
          <img :src="product.picture" :alt="product.name" />
          <a :href="product.linkTo" alt="product">{{ product.name }}</a>
          <div class="price-info">
            <div :class="{'normal-price': product.price}">{{product.priceRegular}}</div>
            <div class="discount" v-if="product.discount">-{{ product.discount }}%</div>
          </div>
          <div class="price">{{product.price}} </div>
          <img class="home-product" v-if="product.home" src="https://linella.md/assets/img/new/marked.png" alt="produs acasa">
        </div>
      </div>
    </div>
    <button @click="nextSlide">Next</button>
    <div class="navigation-dots">
      <span
          v-for="(slide, index) in slides"
          :key="index"
          :class="{ active: index === currentIndex }"
          @click="goToSlide(index)"
          class="dot"
      ></span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const props = defineProps({
  products: {
    type: Array,
    required: true
  },
  groupSize: {
    type: Number,
    default: 3
  }
});

const currentIndex = ref(0);

const groupProducts = (products, groupSize) => {
  const grouped = [];
  for (let i = 0; i < products.length; i += groupSize) {
    grouped.push(products.slice(i, i + groupSize));
  }
  return grouped;
};

const slides = computed(() => groupProducts(props.products, props.groupSize));

const prevSlide = () => {
  currentIndex.value =
      (currentIndex.value - 1 + slides.value.length) % slides.value.length;
};

const nextSlide = () => {
  currentIndex.value = (currentIndex.value + 1) % slides.value.length;
};

const goToSlide = (index) => {
  currentIndex.value = index;
};
</script>

<style scoped>
.normal-price{
  font-size: 18px;
  color: #535353;
  position: relative;
}
.normal-price:after{
  content: "";
  width: 100%;
  height: 1px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-7deg);
  background: #ED1C24;
  display: inline-block;
}
.price{
  text-align: start;
  width: 100%;
  color: #ED1C24;
  font-size: 23px;
}
.price-info{
  display: flex;
  justify-content: space-between;
  width: 100% ;
}
.discount{
  padding: 2px 3px;
  background: #ED1C24;
  border-radius: 12px 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 14px;
  line-height: 17px;
  letter-spacing: -0.05em;
  color: #FFFFFF;
  font-family: "JetBrains Mono ExtraBold";
}
.home-product{
  max-width: 70px;
  max-height: 50px;
  position: absolute;
  top: 0;
  left: 0;
}
.product img{
  width: 184px;
  height: 184px;
}
.slider {
  display: flex;
  align-items: center;
  width: 100%;
}
.slides {
  display: flex;
  overflow: hidden;
  width: 100%; /* Adjust according to your needs */
  position: relative;
}
.slide {
  min-width: 100%;
  transition: transform 0.5s ease-in-out;
  opacity: 0;
  position: absolute;
  left: 0;
  top: 0;
  appearance: none;
  display: none;
  align-items: center;

}
.slide.active {
  opacity: 1;
  position: relative;
  appearance: auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.product {
  width: 216px;
  height: 403px;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  gap: 10px;
  background-color: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.5);
  padding: 15px;
}
.navigation-dots {
  display: flex;
  justify-content: center;
  gap: 10px;
  position: absolute;
  left: 50%;
  bottom: -30px;
  transform: translateX(-50%);
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: grey;
  margin: 0 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.dot.active {
  background-color: black;
}
</style>