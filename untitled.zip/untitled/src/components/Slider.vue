<template>
  <div class="slider">
    <button @click="prevSlide">Prev</button>
    <div class="slides">
      <div
          v-for="(slide, slideIndex) in slides"
          :key="slideIndex"
          :class="{ active: slideIndex === currentIndex }"
          class="slide"
      >
        <div v-for="product in slide" :key="product.id" class="product">
          <div class="top-product-info">
            <img :src="product.picture" :alt="product.name" />
            <a :href="product.linkTo" alt="product">{{ product.name }}</a>
            <div class="price-info">
              <div class="group-discounted">
                <div v-if="product.price" :class="{'price-discounted':product.price}">{{product.priceRegular}}</div>
                <div class="discount" v-if="product.discount">
                  -{{ product.discount }}%
                </div>
              </div>
              <div :class="{price:product.discount ,'price-normal': !product.discount}">{{ product.price || product.priceRegular }}</div>
            </div>
          </div>
          <img
              class="home-product"
              v-if="product.home"
              src="https://linella.md/assets/img/new/marked.png"
              alt="ProdusAcasa"
          />
          <button
              v-if="!cartCount[product.id]"
              @click="addCart(product)"
              class="add-to-cart"
          >
            <div class="cart-svg">
              <svg
                  width="22"
                  height="23"
                  viewBox="0 0 22 23"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
              >
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M5.68882 4.33563C5.52972 4.33529 5.37635 4.3533 5.23061 4.38753C5.03083 3.94719 4.76693 3.55214 4.46678 3.25199C3.95734 2.74255 3.15389 2.54169 2.04166 2.54169V4.33335C2.72111 4.33335 3.11209 4.4311 3.19988 4.51889C3.53848 4.85749 3.83333 5.54547 3.83333 6.12502L3.84233 6.25171L4.72013 12.3963C3.25136 12.4725 2.11351 13.6131 2.04276 15.039L2.04166 15.9792C2.1284 17.4519 3.26246 18.5847 4.67832 18.6652L4.88169 18.6656C5.2503 19.71 6.24609 20.4584 7.41666 20.4584C8.58682 20.4584 9.5823 19.7105 9.95124 18.6667H12.0488C12.4177 19.7105 13.4132 20.4584 14.5833 20.4584C16.0676 20.4584 17.2708 19.2551 17.2708 17.7709C17.2708 16.2866 16.0676 15.0834 14.5833 15.0834C13.4132 15.0834 12.4177 15.8312 12.0488 16.875H9.95124C9.5823 15.8312 8.58682 15.0834 7.41666 15.0834C6.24651 15.0834 5.25102 15.8312 4.88209 16.875H4.72916C4.2723 16.8476 3.86248 16.4382 3.83172 15.9255L3.83333 15.0834C3.85749 14.6187 4.2645 14.2117 4.77356 14.1864L6.54205 14.1869L6.55487 14.1875H15.5838L15.7161 14.1456C16.3953 13.93 16.9391 13.4186 17.1965 12.7564L17.2909 12.5697L17.5975 11.9622C17.9147 11.3333 18.232 10.7034 18.5411 10.088C19.2983 8.58056 19.7745 7.62255 19.88 7.3873C20.4215 6.17917 19.3245 5.24931 18.2031 5.22951L5.68882 4.33563ZM15.2726 12.3958H6.62195C6.56442 12.3798 6.52059 12.3311 6.51201 12.2704L5.63419 6.12566L18.0711 7.01628C17.8535 7.46008 17.458 8.25274 16.9401 9.28379L16.9271 9.30962C16.6315 9.89812 16.3147 10.5272 15.9979 11.1552L15.6916 11.7619L15.5755 11.9917L15.5318 12.0932C15.485 12.2236 15.3921 12.3308 15.2726 12.3958ZM14.5833 18.6667C15.0781 18.6667 15.4792 18.2656 15.4792 17.7708C15.4792 17.2761 15.0781 16.875 14.5833 16.875C14.0886 16.875 13.6875 17.2761 13.6875 17.7708C13.6875 18.2656 14.0886 18.6667 14.5833 18.6667ZM8.3125 17.7708C8.3125 18.2656 7.91142 18.6667 7.41666 18.6667C6.92191 18.6667 6.52083 18.2656 6.52083 17.7708C6.52083 17.2761 6.92191 16.875 7.41666 16.875C7.91142 16.875 8.3125 17.2761 8.3125 17.7708Z"
                    fill="black"
                />
              </svg>
            </div>
          </button>
          <button
              v-if="cartCount[product.id]"
              class="add-quantity"
          >
            <div class="cart-utility">
              <div @click="minusCart(product)" class="minus-btn">-</div>
              <div class="product-total-quantity" v-if="cartCount[product.id]">{{ cartCount[product.id] }}</div>
              <div @click="plusCart(product)" class="plus-btn">+</div>
            </div>
          </button>
        </div>
      </div>
    </div>
    <button @click="nextSlide">Next</button>
    <div class="navigation-dots">
      <span
          v-for="(slide, index) in slides"
          :key="index"
          :class="{ active: index === currentIndex }"
          @click="goToSlide(index)"
          class="dot"
      ></span>
    </div>
  </div>

  <div class="cart-icon" @click="toggleCart">
    <div v-if="cart.length > 0" class="cart-total">{{ cart.length }}</div>
  </div>

  <div v-if="isCartOpen" class="cart">
    <button class="close-cart" @click="toggleCart">x</button>
    <h2>Shopping Cart</h2>
    <div v-if="cart.length === 0">Your cart is empty.</div>
    <div v-else>
      <div v-for="item in cart" :key="item.id" class="cart-item">
        <img :src="item.picture" :alt="item.name" />
        <div>{{ item.name }}</div>
        <div>{{ item.price || item.priceRegular }} lei x {{ cartCount[item.id] }}</div>
        <button @click="minusCart(item)">-</button>
        <button @click="plusCart(item)">+</button>
      </div>
      <div class="total-sum">Total: {{ cartTotalPrice }} lei</div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const props = defineProps({
  products: {
    type: Array,
    required: true,
  },
  groupSize: {
    type: Number,
    default: 3,
  },
});

const currentIndex = ref(0);

const groupProducts = (products, groupSize) => {
  const grouped = [];
  for (let i = 0; i < products.length; i += groupSize) {
    grouped.push(products.slice(i, i + groupSize));
  }
  return grouped;
};

const slides = computed(() => groupProducts(props.products, props.groupSize));

const prevSlide = () => {
  currentIndex.value =
      (currentIndex.value - 1 + slides.value.length) % slides.value.length;
};

const nextSlide = () => {
  currentIndex.value = (currentIndex.value + 1) % slides.value.length;
};

const goToSlide = (index) => {
  currentIndex.value = index;
};

const cart = ref([]);
const cartCount = ref({});
const isCartOpen = ref(false);

const toggleCart = () => {
  isCartOpen.value = !isCartOpen.value;
};

const addCart = (product) => {
  if (!cartCount.value[product.id]) {
    cart.value.push(product);
    cartCount.value[product.id] = 1;
  } else {
    cartCount.value[product.id]++;
  }
};

const minusCart = (product) => {
  if (cartCount.value[product.id] > 1) {
    cartCount.value[product.id]--;
  } else {
    const index = cart.value.findIndex((item) => item.id === product.id);
    if (index !== -1) {
      cart.value.splice(index, 1);
      delete cartCount.value[product.id];
    }
  }
};

const plusCart = (product) => {
  if (!cartCount.value[product.id]) {
    cartCount.value[product.id] = 1;
  }
  cartCount.value[product.id]++;
};

const cartTotalPrice = computed(() => {
  return cart.value.reduce((total, item) => {
    const price = item.price || item.priceRegular;
    return total + price * cartCount.value[item.id];
  }, 0);
});
</script>

<style scoped>
.group-discounted{
  display: flex;
  justify-content: space-between;
}
.cart-icon {
  position: fixed;
  top: 10px;
  right: 10px;
  cursor: pointer;
  display: flex;
  align-items: center;
  z-index: 1000;
}

.cart-total {
  position: absolute;
  top: -8px;
  right: -8px;
  background-color: red;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.cart {
  position: fixed;
  top: 60px;
  right: 10px;
  width: 250px;
  background-color: white;
  border: 1px solid #ccc;
  padding: 10px;
  z-index: 1000;
}

.cart h2 {
  margin-top: 0;
}

.cart-item {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.cart-item img {
  width: 50px;
  height: 50px;
  margin-right: 10px;
}

.cart-item button {
  margin-left: 5px;
}

.total-sum {
  font-weight: bold;
  margin-top: 10px;
}
.minus-btn,
.plus-btn{
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.cart-utility{
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.top-product-info{
  gap: 30px;
  display: flex;
  flex-direction: column;
}
.add-to-cart,
.add-quantity{
  width: 100%;
  height: 50px;
  background-color: #e2e3e5;
  outline: none;
  border-radius: 7.5px;
  border:none;
}
.add-to-cart:hover{
  background-color: #009640;
  cursor: pointer;
}
.add-to-cart:hover svg {
  fill: #FFFFFF;
}
.add-to-cart svg {
  fill: #009640;
}
.price-discounted{
  font-size: 18px;
  color: #535353;
  position: relative;
}
.price-discounted:after{
  content: "";
  width: 100%;
  height: 1px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-7deg);
  background: #ED1C24;
  display: inline-block;
}
.price{
  text-align: start;
  width: 100%;
  color: #ED1C24;
  font-size: 23px;
}
.price-normal{
  text-align: start;
  width: 100%;
  font-size: 23px;
  color: #584D4D;
}
.price-info{
  display: flex;
  justify-content: space-between;
  width: 100% ;
  flex-direction: column;
}
.discount{
  padding: 2px 3px;
  background: #ED1C24;
  border-radius: 12px 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 14px;
  line-height: 17px;
  letter-spacing: -0.05em;
  color: #FFFFFF;
  font-family: "JetBrains Mono ExtraBold";
}
.home-product{
  max-width: 70px;
  max-height: 50px;
  position: absolute;
  top: 0;
  left: 0;
}
.product img{
  width: 184px;
  height: 184px;
}
.slider {
  display: flex;
  align-items: center;
  width: 100%;
}
.slides {
  display: flex;
  overflow: hidden;
  width: 100%; /* Adjust according to your needs */
  position: relative;
}
.slide {
  min-width: 100%;
  transition: transform 0.5s ease-in-out;
  opacity: 0;
  position: absolute;
  left: 0;
  top: 0;
  appearance: none;
  display: none;
  align-items: center;

}
.slide.active {
  opacity: 1;
  position: relative;
  appearance: auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.product {
  width: 216px;
  height: 403px;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  justify-content: space-between;
  background-color: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.5);
  padding: 15px;
}
.navigation-dots {
  display: flex;
  justify-content: center;
  gap: 10px;
  position: absolute;
  left: 50%;
  bottom: -30px;
  transform: translateX(-50%);
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: grey;
  margin: 0 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.dot.active {
  background-color: black;
}
</style>