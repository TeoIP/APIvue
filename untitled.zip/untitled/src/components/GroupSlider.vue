<template>
  <div class="group-slider">
    <h2>{{ group.name }}</h2>
    <Slider :products="group.products" />
  </div>
</template>

<script setup>
import Slider from './Slider.vue';

const props = defineProps({
  group: {
    type: Object,
    required: true
  }
});
</script>

<style scoped>
.group-slider {
  margin-bottom: 30px;
  position: relative;
}
</style>